import React from 'react'
import { ReturnButton } from '../components/ReturnButton'

export const NotFound = () => <h1 className='notfound'>ERROR 404. NO SE ENCONTRÓ LA PÁGINA <ReturnButton /></h1>