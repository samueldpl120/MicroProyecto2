function LoginPage() {
  return (
    <div>
      Hola Mundo
    </div>
  );
}

export default LoginPage;