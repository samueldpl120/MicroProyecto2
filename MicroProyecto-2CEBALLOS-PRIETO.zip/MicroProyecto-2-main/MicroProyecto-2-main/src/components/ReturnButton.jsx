import React from 'react'
import { Link } from 'react-router-dom'

export const ReturnButton = () => <Link className="GameDetail__btn" to='/'>VOLVER AL INICIO</Link>